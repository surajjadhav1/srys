package series;

public interface Discountable{

	public double getDiscount();

}
