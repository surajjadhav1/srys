package series;

public interface Resetable{
	
	void setReset(int num);
}
