package MetTours;

public class Economy{
	
	public double common(int days, int person){
	return 500 * days * person;

	}

}
