namespace Met_Banking;

interface Discountable
{
    double GetDiscount ();
}