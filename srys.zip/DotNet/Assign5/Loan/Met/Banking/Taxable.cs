namespace Met_Banking;
interface Taxable 
{
    double GetTax ();
}