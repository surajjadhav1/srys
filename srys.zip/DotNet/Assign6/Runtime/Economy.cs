namespace MetTours;


class EconomyTours
{
    public double Common (int days, int Person)=>days*Person*500;
    
}