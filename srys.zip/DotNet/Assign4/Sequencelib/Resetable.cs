namespace Series;

public interface Resetable{
	
	public void SetReset(int num);
}
