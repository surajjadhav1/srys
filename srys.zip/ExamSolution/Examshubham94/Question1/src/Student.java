package school;
public class Student{
	private int id;
	private String name;
	private int DOB;


	
}
