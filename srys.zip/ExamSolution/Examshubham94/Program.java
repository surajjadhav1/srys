import payroll.*;

public class Program{

	public static void main(String[] args){
	
	//string name = "jack";
	//int adrs = Integer.parseInt(args[0]);
	Staff ft = new FullTimeStaff("jill",5005, 2);
	System.out.printf("salery is:%.2f",ft.getWork());


	
	}

}
