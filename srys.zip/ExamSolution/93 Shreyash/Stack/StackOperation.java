interface StackOperations<V> {

	public void push(V item);
	public V pop();
}

